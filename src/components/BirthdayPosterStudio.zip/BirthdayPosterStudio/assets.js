// src/components/BirthdayPosterStudio/assets.js
//
// Single source of truth for every image asset the studio uses.
// Paths are relative to THIS file's location:
//   src/components/BirthdayPosterStudio/assets.js
//   -> ../../assets/...  ==  src/assets/...
// which matches V:\VRS\Brain-Builder\src\assets\... exactly.
// If you place this folder somewhere else, only these seven lines need updating.

import logo from '../../assets/logo.png';
import blackboxgift from '../../assets/birthday/blackboxgift.png';
import blueBalloon from '../../assets/birthday/blueBalloon.png';
import cake from '../../assets/birthday/cake.png';
import multiBalloons from '../../assets/birthday/multiBalloons.png';
import orangeBalloon from '../../assets/birthday/orangeBalloon.png';
import redBalloon from '../../assets/birthday/redBalloon.png';
import starBalloon from '../../assets/birthday/starBalloon.png';

// Every decoration is registered here with a stable key. Templates and the
// "Decorations" sidebar tab both reference decorations by this key, so
// adding a new PNG later is a two-line change (import + entry below).
export const DECORATIONS = {
  blackboxgift: { src: blackboxgift, label: 'Gift Box', defaultSize: 130 },
  blueBalloon: { src: blueBalloon, label: 'Blue Balloon', defaultSize: 110 },
  cake: { src: cake, label: 'Birthday Cake', defaultSize: 150 },
  multiBalloons: { src: multiBalloons, label: 'Balloon Bunch', defaultSize: 190 },
  orangeBalloon: { src: orangeBalloon, label: 'Orange Balloon', defaultSize: 110 },
  redBalloon: { src: redBalloon, label: 'Red Balloon', defaultSize: 110 },
  starBalloon: { src: starBalloon, label: 'Star Balloon', defaultSize: 120 },
};

export const LOGO_SRC = logo;

export const DECORATION_KEYS = Object.keys(DECORATIONS);
