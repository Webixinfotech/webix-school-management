// src/components/BirthdayPosterStudio/hooks/usePosterState.js
//
// Deliberately small. Every template is fixed data (see Templates/templates.js)
// so there is no "layer" state to track any more — just the handful of things
// the user is actually allowed to change:
//   1. which template is selected
//   2. which student is selected (drives name + default photo)
//   3. the name shown on the poster (editable, pre-filled from the student)
//   4. the photo itself + its pan/zoom position inside the frame
import { useState, useCallback, useMemo, useRef } from 'react';
import { TEMPLATES, getTemplate } from '../components/Templates/templates';
import { defaultPhotoTransform, toDataURL } from '../utils/image';

// Shown on every template unless/until real copy is wired up server-side —
// kept fixed (not user-editable) so templates never look broken or empty.
const DEFAULT_NOTE =
  'Wishing you a day filled with joy, laughter and wonderful memories. Have a fantastic year ahead!';

export function usePosterState({ initialTemplateId = TEMPLATES[0].id } = {}) {
  // ---- student ----------------------------------------------------------
  const [selectedPersonId, setSelectedPersonId] = useState('');
  const [name, setName] = useState('');

  // ---- template (fixed design, just pick which one) ----------------------
  const [templateId, setTemplateId] = useState(initialTemplateId);
  const template = useMemo(() => getTemplate(templateId), [templateId]);

  // ---- photo: the only visual thing the user actually edits --------------
  const [photoSrc, setPhotoSrc] = useState('');
  const [isCustomPhoto, setIsCustomPhoto] = useState(false); // true once user uploads their own
  const [photoTransform, setPhotoTransform] = useState(defaultPhotoTransform());
  const [photoReady, setPhotoReady] = useState(true); // false while background data-URL conversion is in flight
  const photoRequestId = useRef(0); // guards against a stale conversion overwriting a newer selection

  const setPhoto = useCallback((src, { custom = false } = {}) => {
    const requestId = ++photoRequestId.current;

    // Show the raw URL immediately so the preview isn't blocked/delayed —
    // uploads are already data: URLs, so this is instant for those.
    setPhotoSrc(src || '');
    setIsCustomPhoto(custom);
    setPhotoTransform(defaultPhotoTransform());

    if (!src || src.startsWith('data:')) {
      setPhotoReady(true);
      return;
    }

    // Remote URL (S3/Firebase/etc.): convert to a base64 data-URL in the
    // background. This is what makes the download reliable — see the big
    // comment on toDataURL() in utils/image.js for why the raw remote URL
    // can display fine on screen yet still export blank.
    setPhotoReady(false);
    toDataURL(src).then((dataUrl) => {
      if (photoRequestId.current !== requestId) return; // a newer photo was selected meanwhile
      setPhotoSrc(dataUrl);
      setPhotoReady(true);
    });
  }, []);

  const panPhoto = useCallback((pos) => {
    setPhotoTransform((prev) => ({ ...prev, x: pos.x, y: pos.y }));
  }, []);

  const setZoom = useCallback((scale) => {
    setPhotoTransform((prev) => ({ ...prev, scale }));
  }, []);

  const resetPhotoPosition = useCallback(() => {
    setPhotoTransform(defaultPhotoTransform());
  }, []);

  // ---- student selection: auto-fills name + profile photo ---------------
  const selectStudent = useCallback((id, birthdays = []) => {
    setSelectedPersonId(id);
    const person = birthdays.find((p) => String(p.id) === String(id));
    if (person) {
      setName(person.name || '');
      const photoUrl = person.photo || '';
      setPhoto(photoUrl, { custom: false });
      if (!photoUrl) {
        console.warn('Student selected but no photo available:', { id, person });
      } else {
        console.log('Student selected with photo:', { id, photo: photoUrl });
      }
    } else {
      console.warn('Student not found:', { id, birthdays });
    }
  }, [setPhoto]);

  // If the user picks a new template, keep their student/name/photo — only
  // the design changes, exactly as requested (template swap must never
  // disturb the content already filled in).
  const selectTemplate = useCallback((id) => {
    setTemplateId(id);
  }, []);

  // Restore the profile photo (undo a manual upload) for the current student.
  const useProfilePhoto = useCallback((birthdays = []) => {
    const person = birthdays.find((p) => String(p.id) === String(selectedPersonId));
    setPhoto(person?.photo || '', { custom: false });
  }, [selectedPersonId, setPhoto]);

  return {
    // student
    selectedPersonId, name, setName, selectStudent,
    // template
    templateId, template, TEMPLATES, selectTemplate,
    // photo
    photoSrc, isCustomPhoto, setPhoto, panPhoto, setZoom, photoTransform,
    resetPhotoPosition, useProfilePhoto, photoReady,
    // fixed copy
    note: DEFAULT_NOTE,
  };
}
