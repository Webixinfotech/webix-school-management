// src/components/BirthdayPosterStudio/utils/download.js
import html2canvas from 'html2canvas';
import { ensureImageUrl } from './image';

export const BASE_SIZE = 1080;
export const EXPORT_SIZES = [1080, 2048, 4096];

/**
 * Waits for all images in a DOM node to fully load before proceeding.
 * This ensures that profile photos and decorative assets are ready
 * before html2canvas captures them.
 */
async function waitForImagesLoaded(node) {
  const images = node.querySelectorAll('img');
  if (images.length === 0) return;

  const imagePromises = Array.from(images).map((img) => {
    return new Promise((resolve) => {
      // If image is already loaded, resolve immediately
      if (img.complete && img.naturalHeight !== 0) {
        resolve();
      } else {
        // Wait for load event
        img.addEventListener('load', resolve, { once: true });
        // Also resolve on error to avoid hanging
        img.addEventListener('error', resolve, { once: true });
        // Set a timeout in case image never loads
        setTimeout(resolve, 3000);
      }
    });
  });

  await Promise.all(imagePromises);
}

/**
 * Captures the poster node (always laid out at BASE_SIZE) and scales it up
 * with html2canvas's `scale` option so a 4096px export is rendered crisp,
 * not stretched — the DOM itself never changes, only the raster output does.
 * 
 * Fixed: Now waits for all images to load before capturing to ensure
 * profile photos and decorations appear in the downloaded poster.
 */
export async function exportPoster(node, { format = 'png', size = 1080, filename = 'poster' } = {}) {
  if (!node) throw new Error('Nothing to export yet');
  
  // Update image sources to ensure CORS compatibility
  const images = node.querySelectorAll('img');
  images.forEach((img) => {
    if (img.src && !img.src.startsWith('data:')) {
      img.src = ensureImageUrl(img.src);
    }
  });
  
  // Wait for all images to load first
  await waitForImagesLoaded(node);
  
  // Add a small delay to ensure rendering is complete
  await new Promise(resolve => setTimeout(resolve, 100));
  
  const scale = size / BASE_SIZE;

  const canvas = await html2canvas(node, {
    backgroundColor: format === 'jpg' ? '#ffffff' : null,
    scale,
    useCORS: true,
    allowTaint: true,
    logging: false,
    width: BASE_SIZE,
    height: BASE_SIZE,
    imageTimeout: 5000,
    onclone: (clonedDocument) => {
      // Ensure all images in the cloned document are visible and have proper URLs
      const clonedImages = clonedDocument.querySelectorAll('img');
      clonedImages.forEach((img) => {
        img.style.opacity = '1';
        img.style.visibility = 'visible';
        img.style.display = 'block';
        // Update cloned image URLs as well
        if (img.src && !img.src.startsWith('data:')) {
          img.src = ensureImageUrl(img.src);
        }
      });
    },
  });

  const mime = format === 'jpg' ? 'image/jpeg' : 'image/png';
  const quality = format === 'jpg' ? 0.95 : undefined;
  const dataUrl = canvas.toDataURL(mime, quality);

  const link = document.createElement('a');
  link.download = `${filename}.${format === 'jpg' ? 'jpg' : 'png'}`;
  link.href = dataUrl;
  link.click();

  return dataUrl;
}
