// src/components/BirthdayPosterStudio/index.jsx
import { useRef, useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { Sparkles, Download, Loader2 } from 'lucide-react';
import ControlPanel from './components/Panel/ControlPanel';
import ScaledCanvas from './components/Canvas/ScaledCanvas';
import PosterCanvas from './components/Canvas/PosterCanvas';
import { CANVAS } from './components/Templates/templates';
import { usePosterState } from './hooks/usePosterState';
import { exportPoster } from './utils/download';

/**
 * BirthdayPosterStudio
 *
 * Drop-in replacement for the old PosterStudio component. Same public API:
 *   <BirthdayPosterStudio birthdays={birthdays} onToast={showToast} />
 *
 * `birthdays` items are expected in the same shape the existing API already
 * returns: { id, name, phone, photo, daysRemaining, class? }. Nothing about
 * how that data is fetched has changed — this component only consumes it.
 *
 * Every poster design is FIXED (see components/Templates/templates.js).
 * The only things a user can change are: which template, which student,
 * the name shown, and the photo (upload + drag to reposition + zoom).
 * The preview shown on screen is exactly what gets downloaded.
 */
export default function BirthdayPosterStudio({ birthdays = [], onToast }) {
  const s = usePosterState();
  const exportRef = useRef(null);
  const [downloading, setDownloading] = useState(false);

  const toast = (msg, type = 'success') => onToast?.(msg, type);

  // Auto-select the first student on initial load to show a preview
  useEffect(() => {
    if (birthdays.length > 0 && !s.selectedPersonId) {
      console.log('Auto-selecting first student:', {
        total: birthdays.length,
        first: birthdays[0],
      });
      s.selectStudent(String(birthdays[0].id), birthdays);
    }
  }, [birthdays.length, s.selectedPersonId, s]);

  const handleDownload = async () => {
    if (!s.name.trim()) {
      toast('Add a name before downloading', 'error');
      return;
    }
    if (!s.photoReady) {
      toast('Just a sec, still preparing the photo…', 'error');
      return;
    }
    setDownloading(true);
    try {
      await exportPoster(exportRef.current, {
        format: 'png',
        size: 2048,
        filename: (s.name || 'birthday-poster').trim().replace(/\s+/g, '-').toLowerCase(),
      });
      toast('Poster downloaded 🎉');
    } catch (err) {
      toast('Download failed, please try again', 'error');
    } finally {
      setDownloading(false);
    }
  };

  const canvasProps = {
    template: s.template,
    name: s.name,
    note: s.note,
    photoSrc: s.photoSrc,
    photoTransform: s.photoTransform,
    onPanPhoto: s.panPhoto,
  };

  return (
    <div className="h-full min-h-[640px] flex flex-col bg-[#F4F1EA] rounded-2xl overflow-hidden border border-[#EDE8DC]">
      {/* Header */}
      <div className="h-14 shrink-0 flex items-center justify-between px-4 border-b border-[#EDE8DC] bg-white/80 backdrop-blur-sm">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#1B1230] to-[#3a2145] flex items-center justify-center shrink-0">
            <Sparkles size={15} className="text-[#C9A24B]" />
          </div>
          <div className="min-w-0">
            <div className="text-sm font-semibold text-[#2B2440] leading-tight">Birthday Poster Studio</div>
            <div className="text-[11px] text-[#9a92a8] leading-tight truncate">{s.template.name} template</div>
          </div>
        </div>

        <button
          onClick={handleDownload}
          disabled={downloading || !s.photoReady}
          className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-[#C9A24B] to-[#a8842f] text-white text-xs font-semibold disabled:opacity-60 shrink-0"
        >
          {downloading ? <Loader2 size={13} className="animate-spin" /> : <Download size={13} />}
          <span>Download</span>
        </button>
      </div>

      {/* Body: canvas + panel, stacked on mobile, side-by-side from lg up */}
      <div className="flex-1 overflow-y-auto lg:overflow-hidden flex flex-col lg:flex-row">
        <div className="flex-1 lg:overflow-y-auto flex items-start justify-center p-4 md:p-8">
          <div className="w-full max-w-md">
            <ScaledCanvas {...canvasProps} editable />
            <p className="text-center text-[11px] text-[#9a92a8] mt-3">
              Drag the photo to reposition it · what you see here is exactly what downloads
            </p>
          </div>
        </div>

        <div className="w-full lg:w-96 shrink-0 border-t lg:border-t-0 lg:border-l border-[#EDE8DC] bg-[#F4F1EA] lg:overflow-y-auto p-4">
          <ControlPanel s={s} birthdays={birthdays} toast={toast} />
        </div>
      </div>

      {/*
        Hidden, unscaled, full-resolution clone of the poster used ONLY for
        export. The visible preview above is deliberately shrunk with a CSS
        transform (`scale(...)`) so it fits the screen — but html2canvas
        renders a node based on its own layout box, and capturing a node
        that sits inside a transform-scaled ancestor produces exactly the
        squished / overlapping / cropped output you saw. Rendering a second,
        identical copy at true 1080×1080 size, off-screen via a portal
        (so no ancestor transform, overflow or scale can touch it), and
        capturing THAT instead, guarantees the download always matches the
        editor pixel-for-pixel.
      */}
      {typeof document !== 'undefined' &&
        createPortal(
          <div
            aria-hidden="true"
            style={{ position: 'fixed', top: 0, left: '-10000px', width: CANVAS, height: CANVAS, pointerEvents: 'none' }}
          >
            <PosterCanvas ref={exportRef} scale={1} editable={false} {...canvasProps} />
          </div>,
          document.body
        )}
    </div>
  );
}
